const Alexa = require('ask-sdk-core');  
  
const TurnLightOnHandler = {  
  canHandle(handlerInput) {  
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest'  
      || (handlerInput.requestEnvelope.request.type === 'IntentRequest'  
      && handlerInput.requestEnvelope.request.intent.name === 'TurnLightsOnIntent');  
  },  
  async handle(handlerInput) {  
    let outputSpeech = 'This is the default message.';  
  
    await getRemoteData('https://fee2-176-24-19-161.eu.ngrok.io/on')  
      .then((response) => {  
        //const data = JSON.parse(response);  
        outputSpeech = `The light has just been switched on.`; 
      })  
      .catch((err) => {  
        console.log(`ERROR: ${err.message}`);  
          
      });  
  
    return handlerInput.responseBuilder  
      .speak(outputSpeech)  
      .getResponse();  
  },  
};  

const TurnLightOffHandler = {  
  canHandle(handlerInput) {  
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest'  
      || (handlerInput.requestEnvelope.request.type === 'IntentRequest'  
      && handlerInput.requestEnvelope.request.intent.name === 'TurnLightsOffIntent');  
  },  
  async handle(handlerInput) {  
    let outputSpeech = 'This is the default message.';  
  
    await getRemoteData('https://fee2-176-24-19-161.eu.ngrok.io/off')  
      .then((response) => {  
        //const data = JSON.parse(response);  
        outputSpeech = `The light has just been switched off.`; 
      })  
      .catch((err) => {  
        console.log(`ERROR: ${err.message}`);  
          
      });  
  
    return handlerInput.responseBuilder  
      .speak(outputSpeech)  
      .getResponse();  
  },  
};  
  
const HelpIntentHandler = {  
  canHandle(handlerInput) {  
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'  
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';  
  },  
  handle(handlerInput) {  
    const speechText = 'Alexa can turn an LED on for you';  
  
    return handlerInput.responseBuilder  
      .speak(speechText)  
      .reprompt(speechText)  
      .getResponse();  
  },  
};  
  
const CancelAndStopIntentHandler = {  
  canHandle(handlerInput) {  
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'  
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'  
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');  
  },  
  handle(handlerInput) {  
    const speechText = 'Goodbye, dont you want to play with LED!';  
  
    return handlerInput.responseBuilder  
      .speak(speechText)  
      .getResponse();  
  },  
};  
  
const SessionEndedRequestHandler = {  
  canHandle(handlerInput) {  
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';  
  },  
  handle(handlerInput) {  
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);  
  
    return handlerInput.responseBuilder.getResponse();  
  },  
};  
  
const ErrorHandler = {  
  canHandle() {  
    return true;  
  },  
  handle(handlerInput, error) {  
    console.log(`Error handled: ${error.message}`);  
  
    return handlerInput.responseBuilder  
      .speak('Sorry, I can\'t understand the command. Please say again.')  
      .reprompt('Sorry, I can\'t understand the command. Please say again.')  
      .getResponse();  
  },  
};  
  
const getRemoteData = (url) => new Promise((resolve, reject) => {  
  const client = url.startsWith('https') ? require('https') : require('http');  
  const request = client.get(url, (response) => {  
    if (response.statusCode < 200 || response.statusCode > 299) {  
      reject(new Error(`Failed with status code: ${response.statusCode}`));  
    }  
    const body = [];  
    response.on('data', (chunk) => body.push(chunk));  
    response.on('end', () => resolve(body.join('')));  
  });  
  request.on('error', (err) => reject(err));  
});  
  
const skillBuilder = Alexa.SkillBuilders.custom();  
  
exports.handler = skillBuilder  
  .addRequestHandlers(  
    TurnLightOnHandler,
    TurnLightOffHandler,
    HelpIntentHandler,  
    CancelAndStopIntentHandler,  
    SessionEndedRequestHandler,  
  )  
  .addErrorHandlers(ErrorHandler)  
  .lambda();  